import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  Alert as RNAlert,
  Picker,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useStations } from '@/hooks/useStations';
import { useCalibrations } from '@/hooks/useCalibrations';
import { useAuth } from '@/hooks/useAuth';
import { ChevronLeft, CheckCircle } from 'lucide-react-native';

export default function CalibrationScreen() {
  const { id } = useLocalSearchParams();
  const { getStation } = useStations();
  const { addCalibration } = useCalibrations();
  const { user } = useAuth();
  const router = useRouter();

  const station = getStation(id as string);
  const [sensorType, setSensorType] = useState<'ph' | 'temperature' | 'turbidity' | 'conductivity' | 'oxygen'>('ph');
  const [calibrationValue, setCalibrationValue] = useState('');
  const [standardValue, setStandardValue] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCalibrate = async () => {
    if (!calibrationValue || !standardValue) {
      RNAlert.alert('Erreur', 'Veuillez remplir tous les champs');
      return;
    }

    setLoading(true);
    try {
      await addCalibration({
        stationId: id as string,
        sensorType,
        calibratedAt: new Date().toISOString(),
        calibrationValue: parseFloat(calibrationValue),
        standardValue: parseFloat(standardValue),
        technician: user?.name || 'Anonyme',
        notes,
        nextCalibrationDate: new Date(Date.now() + 30 * 24 * 3600000).toISOString(),
      });

      RNAlert.alert('Succès', 'Calibration enregistrée', [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error) {
      RNAlert.alert('Erreur', 'Impossible d\'enregistrer la calibration');
    } finally {
      setLoading(false);
    }
  };

  if (!station) {
    return (
      <View style={styles.container}>
        <Text style={styles.error}>Station non trouvée</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()}>
          <ChevronLeft size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.title}>Calibration</Text>
        <View style={{ width: 24 }} />
      </View>

      <View style={styles.content}>
        <View style={styles.stationInfo}>
          <Text style={styles.stationName}>{station.name}</Text>
          <Text style={styles.stationLocation}>{station.location}</Text>
        </View>

        <Text style={styles.sectionTitle}>Guide de Calibration</Text>
        <View style={styles.guideBox}>
          <View style={styles.guideStep}>
            <Text style={styles.stepNumber}>1</Text>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Préparer les solutions</Text>
              <Text style={styles.stepText}>Préparé les solutions d'étalonnage appropriées</Text>
            </View>
          </View>
          <View style={styles.guideStep}>
            <Text style={styles.stepNumber}>2</Text>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Mesurer le capteur</Text>
              <Text style={styles.stepText}>Plonger le capteur et noter la valeur</Text>
            </View>
          </View>
          <View style={styles.guideStep}>
            <Text style={styles.stepNumber}>3</Text>
            <View style={styles.stepContent}>
              <Text style={styles.stepTitle}>Enregistrer les résultats</Text>
              <Text style={styles.stepText}>Compléter le formulaire ci-dessous</Text>
            </View>
          </View>
        </View>

        <Text style={styles.sectionTitle}>Formulaire de Calibration</Text>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Type de Capteur</Text>
          <Picker
            selectedValue={sensorType}
            onValueChange={setSensorType}
            style={styles.picker}
          >
            <Picker.Item label="pH" value="ph" />
            <Picker.Item label="Température" value="temperature" />
            <Picker.Item label="Turbidité" value="turbidity" />
            <Picker.Item label="Conductivité" value="conductivity" />
            <Picker.Item label="Oxygène" value="oxygen" />
          </Picker>
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Valeur du Capteur</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: 7.25"
            placeholderTextColor="#666"
            value={calibrationValue}
            onChangeText={setCalibrationValue}
            keyboardType="decimal-pad"
            editable={!loading}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Valeur Standard</Text>
          <TextInput
            style={styles.input}
            placeholder="Ex: 7.00"
            placeholderTextColor="#666"
            value={standardValue}
            onChangeText={setStandardValue}
            keyboardType="decimal-pad"
            editable={!loading}
          />
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Notes (optionnel)</Text>
          <TextInput
            style={[styles.input, styles.inputMultiline]}
            placeholder="Ajouter des notes..."
            placeholderTextColor="#666"
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={4}
            editable={!loading}
          />
        </View>

        <TouchableOpacity
          style={[styles.button, loading && styles.buttonDisabled]}
          onPress={handleCalibrate}
          disabled={loading}
        >
          <CheckCircle size={20} color="#fff" />
          <Text style={styles.buttonText}>{loading ? 'Enregistrement...' : 'Enregistrer Calibration'}</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f1419',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#1a1f26',
    borderBottomWidth: 1,
    borderBottomColor: '#2d3139',
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: '#fff',
  },
  error: {
    color: '#ff3333',
    textAlign: 'center',
    marginTop: 20,
  },
  content: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  stationInfo: {
    backgroundColor: '#1a1f26',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
    borderLeftWidth: 3,
    borderLeftColor: '#0066ff',
  },
  stationName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  stationLocation: {
    fontSize: 12,
    color: '#999',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 10,
    marginTop: 16,
  },
  guideBox: {
    backgroundColor: '#1a1f26',
    borderRadius: 8,
    padding: 12,
    marginBottom: 20,
  },
  guideStep: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#0066ff',
    color: '#fff',
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'center',
    textAlignVertical: 'center',
    marginRight: 12,
  },
  stepContent: {
    flex: 1,
  },
  stepTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 2,
  },
  stepText: {
    fontSize: 12,
    color: '#999',
  },
  formGroup: {
    marginBottom: 14,
  },
  label: {
    fontSize: 12,
    fontWeight: '600',
    color: '#e0e0e0',
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: '#2d3139',
    borderRadius: 6,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: '#fff',
    backgroundColor: '#1a1f26',
  },
  inputMultiline: {
    height: 100,
    textAlignVertical: 'top',
    paddingTop: 10,
  },
  picker: {
    backgroundColor: '#1a1f26',
    color: '#fff',
    borderWidth: 1,
    borderColor: '#2d3139',
    borderRadius: 6,
  },
  button: {
    backgroundColor: '#00d084',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,
    paddingVertical: 12,
    marginTop: 20,
    gap: 8,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
});
